<?php setcookie("user", "tas27", time() - 3600);?>
<html>