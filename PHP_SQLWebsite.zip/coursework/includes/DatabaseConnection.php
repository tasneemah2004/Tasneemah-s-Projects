<?php
 $pdo = new PDO('mysql:host=mysql.cms.gre.ac.uk; dbname=mdb_tb0941k; charset=utf8mb4', 'tb0941k', 'tb0941k');