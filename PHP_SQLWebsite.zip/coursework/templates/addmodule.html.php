<form action="" method="post">
    <label for='moduleName'>Type your module here</label>
    <textarea name="moduleName" rows="3" cols="40"></textarea>


</select>
    <input type="submit" name="submit" value="Add">
</form>