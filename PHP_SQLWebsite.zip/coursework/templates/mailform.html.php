<form action="" method="post">
    <textarea name="message" rows="15" cols="40"></textarea>
    <input type="submit" value="send email">
</form>