<form action="" method="post">
    <label for='name'>Type author name here:</label>
    <textarea name="name" rows="3" cols="40"></textarea>


</select>
    <input type="submit" name="submit" value="Add">
</form>