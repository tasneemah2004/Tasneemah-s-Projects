<?php require "Check.php";?>
<html>
<head>
<title>protected page</title>
</head>
<body>
Welcome to the protected page!!<br />
you are logged in
<a href="Logout.php">logout</a>
</body>
</html>